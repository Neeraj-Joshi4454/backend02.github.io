const express = require('express');


const app = express();

const port = 3000;


app.get('/', (req, res) => {

    res.send('hello from Express')
})


app.get('/services', (req, res) => {

    res.send('Services Page')

})


app.get('/data', (req, res) => {

    res.send({

        id:1,
        name : 'felix'
    })

    


})


app.listen(port, () => {

    console.log('server is started on port :', port)
})