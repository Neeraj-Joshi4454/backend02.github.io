const fs = require('fs');

// blocking call of read File
// const data = fs.readFileSync('demo.txt', 'utf-8');

// console.log(data);

// console.log('Hello world');

// Non-blocking call of read File



// fs.readFile( 'demo.txt', 'utf-8', (err, data) => {

//     console.log('Reading of file is completed')
//     console.log(`data is : ${data}`)

// } )

// console.log("hello world");



// creating a new file


// const text = "hello from node js and we are learning the nodejs " 


// fs.writeFile('new.txt', text, (err, data) => {

//     console.log('File is created');

// });


