const fs = require('fs');
const http = require('http');


const port = 8000;
const hostname = '127.0.0.1';

const server = http.createServer( (req, res) => {

    const home = fs.readFileSync('home.html')
    const services = fs.readFileSync('services.html')
    const about = fs.readFileSync('about.html')
    const contact = fs.readFileSync('contact.html')

    res.setHeader('Content-Type', 'text/html');



    if( req.url == '/' ){

        res.end(home)
    }
    else if( req.url == '/services' ){

        res.end(services)
    }
    else if( req.url == '/about' ){

        res.end(about)
    }
    else if( req.url == '/contact' ){

        res.end(contact)
    }
    else{

        res.end('404 page not found')
    }
    

} )


server.listen( port, hostname, () => {

    console.log(`server is running on http://${hostname}:${port}`);

} )