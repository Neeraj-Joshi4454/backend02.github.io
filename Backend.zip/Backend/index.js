const fs = require('fs');



fs.readFile('demo.txt', 'utf-8', (err, data) => {

    
    console.log(`your data is ${data}`)


})

console.log('Hello world')




