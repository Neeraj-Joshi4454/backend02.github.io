

console.log("Hello from node js");