const http = require('http');
const fs = require('fs');




const port = 8000;
const hostname = '127.0.0.1'


const server = http.createServer();



server.on('request', (req, res) => {


    // const newStream = fs.createReadStream('./test.txt');

    // 1)data

//     newStream.on('data', (resData) => {

//         res.write(resData);


//     })
    


//     // 2)end

//     newStream.on('end', () => {

//         res.end();
//     })


//     // 3)error

//     newStream.on('error', (err) => {

//         alert(err);
//         res.end('File not found / no internet connection')

//     })



    const newStream = fs.createReadStream('./test.txt');

    newStream.pipe(res)


})



server.listen( port, hostname, (err) =>{

    console.log(`server is started on http://${hostname}:${port}`);


} )





