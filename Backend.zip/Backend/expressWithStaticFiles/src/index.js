const express = require('express');
const path = require('path');
const hbs = require('hbs');


const app = express();

const userName = "Felix ITS"
// const staticPath = path.join(__dirname, '../public')
const tempPath = path.join(__dirname, '../templates/views');
const partialsPath = path.join(__dirname, '../templates/partials');
// app.use(express.static(staticPath))
const port = 3000;

// setting up view Engine
app.set('view engine', "hbs")

// setting up temp folder
app.set('views', tempPath)

// register Paritals path

hbs.registerPartials(partialsPath)


app.get('/',(req, res) => {

    res.render("index", {

        name : userName ,
        course : 'FULL-STACK'  
    })

})

app.get('/about', (req, res) => {

    res.render('about')

})

app.get('/', (req, res) => {

    res.send('Hello from express app');

})


app.get('/about', (req, res) => {

    res.render("about")

})


app.listen(port, () => {

    console.log(`listening on http://127.0.0.1:${port}`)
})
