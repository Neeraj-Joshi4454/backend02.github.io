
const operations = require('./module')




console.log(operations.add(30,30));
console.log(operations.sub(50,30));
console.log(operations.mul(2,8))








