const http = require('http')
const fs = require('fs')


const port = '8000';
const host = '127.0.0.1';


const server = http.createServer( (req, res) => {
    
    const home = fs.readFileSync('home.html');
    res.setHeader('Content-Type', 'text/html');
    
    if( req.url == '/' ){
       res.end(home)
       
    }
    else if( req.url == '/services' ){

        res.end('Services Page');
    }
    else if( req.url == '/about' ){

        res.end('about page')

    }
    else if( req.url == '/contact' ){

        res.end('Contact Page')

    }
    else{

        res.end('page not found')

    }

} )

server.listen(port, host, () => {

    console.log(`server is started on : http://${host}:${port}`)

})



